import Link from "next/link";
import { ArrowUpRight, MoveUpRight, Orbit } from "lucide-react";
import { DESTINATIONS, type Destination } from "./catalog";

export function ContentCompanions({ page }: { page: Destination }) {
  const related = DESTINATIONS.filter(item => item.group === page.group && item.href !== page.href && !["/about", "/dashboard"].includes(item.href)).slice(0, 3);
  return <section className="es-companions" aria-label="Continue exploring"><div className="es-companions-heading"><p className="es-kicker">FOLLOW YOUR CURIOSITY</p><h2>There’s always<br /><em>more to discover.</em></h2><Link href="/dashboard">All destinations<ArrowUpRight size={14} /></Link></div><div className="es-companions-links">{related.map((item, i) => <Link href={item.href} key={item.href}><span>{String(i + 1).padStart(2, "0")}</span><item.icon size={23} strokeWidth={1.2} /><div><small>{item.group}</small><h3>{item.label}</h3></div><MoveUpRight size={19} /></Link>)}</div></section>;
}
export function ContentFooter() {
  return <footer className="es-editorial-footer"><div className="es-footer-main"><Link href="/" className="es-footer-brand"><Orbit size={30} strokeWidth={1.2} />earthsphere<span>.</span></Link><p>A little curiosity.<br />A different perspective.</p><nav aria-label="Footer"><Link href="/about">Our story<ArrowUpRight size={12} /></Link><Link href="/dashboard">Find your next discovery<ArrowUpRight size={12} /></Link><a href="https://api.nasa.gov/" target="_blank" rel="noopener noreferrer">NASA Open APIs<ArrowUpRight size={12} /></a></nav></div><div className="es-footer-bottom"><span>Independent platform. Shared curiosity.</span><span>Made on Earth, for everyone on it.</span><a href="#page-content">Back to top ↑</a></div></footer>;
}
