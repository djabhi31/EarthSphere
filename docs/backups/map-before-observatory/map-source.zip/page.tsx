"use client";
import { getLatestGeometry } from "@/lib/utils";

import { useState, useCallback, useMemo, useRef } from "react";
import dynamic from "next/dynamic";
import { useEvents } from "@/hooks/useEvents";
import { MapControls } from "@/components/map/MapControls";
import { MapSidebar } from "@/components/map/MapSidebar";
import { MapLegend } from "@/components/map/MapLegend";
import { EventDetailPanel } from "@/components/map/EventDetailPanel";
import { TimelinePlayer } from "@/components/map/TimelinePlayer";
import { HotspotPresets } from "@/components/map/HotspotPresets";
import { RadarOverlay } from "@/components/map/RadarOverlay";
import { DayNightTerminator } from "@/components/map/DayNightTerminator";
import { TectonicPlatesOverlay } from "@/components/map/TectonicPlatesOverlay";
import { LayerOpacityControl } from "@/components/map/LayerOpacityControl";
import { MapPitchControls } from "@/components/map/MapPitchControls";
import { CATEGORY_CONFIG } from "@/lib/utils";
import type { TileLayerType } from "@/components/map/EventMap";
import type { EONETEvent } from "@/lib/types";
import maplibregl from "maplibre-gl";
import { useEarthSphereStore } from "@/lib/store";

const EventMap = dynamic(() => import("@/components/map/EventMap"), {
  ssr: false,
  loading: () => (
    <div className="h-screen w-full bg-canvas flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="h-12 w-12 rounded-full border-2 border-electric-cyan/30 border-t-electric-cyan animate-spin" />
        <p className="text-text-muted text-sm">Loading map…</p>
      </div>
    </div>
  ),
});

export default function MapPage() {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState<"open" | "closed" | "all">("open");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedEvent, setSelectedEvent] = useState<EONETEvent | null>(null);
  const [tileLayer, setTileLayer] = useState<TileLayerType>("dark");
  const [timeFilteredEvents, setTimeFilteredEvents] = useState<EONETEvent[] | null>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const [mapInstance, setMapInstance] = useState<maplibregl.Map | null>(null);

  const dateRange = useEarthSphereStore((state) => state.dateRange);
  const setDateRange = useEarthSphereStore((state) => state.setDateRange);
  const heatmapEnabled = useEarthSphereStore((state) => state.heatmapEnabled);
  const toggleHeatmap = useEarthSphereStore((state) => state.toggleHeatmap);
  const radarEnabled = useEarthSphereStore((state) => state.radarEnabled);
  const toggleRadar = useEarthSphereStore((state) => state.toggleRadar);
  const dayNightEnabled = useEarthSphereStore((state) => state.dayNightEnabled);
  const toggleDayNight = useEarthSphereStore((state) => state.toggleDayNight);
  const tectonicEnabled = useEarthSphereStore((state) => state.tectonicEnabled);
  const toggleTectonic = useEarthSphereStore((state) => state.toggleTectonic);
  const layerOpacity = useEarthSphereStore((state) => state.layerOpacity);

  const { data: eventsData, isLoading, isError, refetch } = useEvents({
    status: "all", // Fetch all and filter locally so we have full data for sidebar search
    days: 60,
  });

  const allEvents = useMemo(() => (eventsData?.events || []) as EONETEvent[], [eventsData]);

  // Sidebar controls filtering logic
  const filteredEvents = useMemo(() => {
    return allEvents.filter(event => {
      // Search
      const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase());

      // Status
      const isActive = event.closed === null;
      const matchesStatus = statusFilter === 'all'
        ? true
        : statusFilter === 'open'
          ? isActive
          : !isActive;

      // Category
      const matchesCategory = selectedCategories.length === 0 ||
        event.categories.some(c => selectedCategories.includes(c.id));

      // Date Range
      let matchesDate = true;
      if (dateRange.start || dateRange.end) {
        const latestGeo = getLatestGeometry(event);
        if (latestGeo) {
          const eventDate = new Date(latestGeo.date);
          const start = dateRange.start ? new Date(dateRange.start) : null;
          const end = dateRange.end ? new Date(dateRange.end) : null;
          if (start && end) {
            matchesDate = eventDate >= start && eventDate <= end;
          } else if (start) {
            matchesDate = eventDate >= start;
          } else if (end) {
            matchesDate = eventDate <= end;
          }
        }
      }

      return matchesSearch && matchesStatus && matchesCategory && matchesDate;
    });
  }, [allEvents, searchQuery, statusFilter, selectedCategories, dateRange]);


  const handleZoomIn = useCallback(() => mapRef.current?.zoomIn(), []);
  const handleZoomOut = useCallback(() => mapRef.current?.zoomOut(), []);

  const displayEvents = timeFilteredEvents ?? filteredEvents;

  return (
    <div className="relative h-svh w-full overflow-hidden bg-canvas">
      <h1 className="sr-only">Earth observations map</h1>
      {/* Main Map */}
      <div className="absolute inset-0" style={{ opacity: layerOpacity }}>
        <RadarOverlay enabled={radarEnabled} />
        <DayNightTerminator enabled={dayNightEnabled} />
        <TectonicPlatesOverlay enabled={tectonicEnabled} />
        {isError ? (
          <div className="h-full w-full flex items-center justify-center text-warning">
            <div className="es-map-error"><p>Unable to load Earth observations.</p><button className="es-button es-button-secondary" onClick={() => { void refetch(); }}>Try again</button></div>
          </div>
        ) : (
          <EventMap
            events={displayEvents}
            tileLayer={tileLayer}
            onEventClick={(id) => {
              const ev = displayEvents.find(e => e.id === id);
              if (ev) setSelectedEvent(ev);
            }}
            selectedEventId={selectedEvent?.id}
            zoom={2.2}
            center={[0, 20]}
            onMapLoad={(map) => { mapRef.current = map; setMapInstance(map); }}
            className="h-full w-full !rounded-none"
            heatmapEnabled={heatmapEnabled}
          />
        )}
      </div>

      <MapSidebar
        events={allEvents}
        filteredEvents={filteredEvents}
        selectedEvent={selectedEvent}
        onSelectEvent={setSelectedEvent}
        isLoading={isLoading}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        statusFilter={statusFilter}
        setStatusFilter={setStatusFilter}
        selectedCategories={selectedCategories}
        setSelectedCategories={setSelectedCategories}
        dateStart={dateRange.start}
        dateEnd={dateRange.end}
        onDateChange={(start, end) => setDateRange({ start, end })}
      />

      <MapLegend categories={CATEGORY_CONFIG} />

      <div className="absolute top-28 right-5 z-30 hidden md:flex items-center gap-2">
        <LayerOpacityControl />
        <HotspotPresets map={mapInstance} />
      </div>

      <TimelinePlayer
        events={filteredEvents}
        onTimelineFilter={setTimeFilteredEvents}
      />

      <div className="absolute bottom-6 right-4 z-30 flex flex-col gap-3 items-end">
        <MapPitchControls map={mapInstance} />
        <MapControls
          onZoomIn={handleZoomIn}
          onZoomOut={handleZoomOut}
          onTileChange={setTileLayer}
          activeTile={tileLayer}
          showLegend={false}
          heatmapEnabled={heatmapEnabled}
          onToggleHeatmap={toggleHeatmap}
          radarEnabled={radarEnabled}
          onToggleRadar={toggleRadar}
          dayNightEnabled={dayNightEnabled}
          onToggleDayNight={toggleDayNight}
          tectonicEnabled={tectonicEnabled}
          onToggleTectonic={toggleTectonic}
        />
      </div>

      <EventDetailPanel
        event={selectedEvent}
        onClose={() => setSelectedEvent(null)}
      />
    </div>
  );
}
