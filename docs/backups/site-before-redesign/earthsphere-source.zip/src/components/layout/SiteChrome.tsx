"use client";

import { usePathname } from "next/navigation";
import { Navbar } from "./Navbar";
import { CustomCursor } from "@/components/ui/CustomCursor";
import { ScrollProgress } from "@/components/ui/ScrollProgress";

/** The cinematic homepage supplies its own navigation and motion controls. */
export function SiteChrome() {
  const pathname = usePathname();
  if (pathname === "/" || pathname === "/landing-v1") return null;
  return <><ScrollProgress /><Navbar /><CustomCursor /></>;
}
