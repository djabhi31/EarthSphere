"use client";
import { type CSSProperties, type ReactNode } from "react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { MotionConfig } from "motion/react";
import { ArrowUpRight, Orbit } from "lucide-react";
import { SiteChrome } from "@/components/layout/SiteChrome";
import { destinationFor } from "./catalog";
import { PageIntro } from "./PageIntro";

export function SiteShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const preserved = pathname.startsWith("/landing-");
  const immersive = ["/", "/map", "/explore"].includes(pathname);
  const detail = pathname.startsWith("/events/");
  const page = destinationFor(pathname);
  const Content = pathname === "/" || pathname === "/explore" ? "div" : "main";
  if (preserved) return <><SiteChrome />{children}</>;
  return <MotionConfig reducedMotion="user"><div className={`es-site ${immersive ? "es-immersive" : ""}`} data-page={pathname.split("/")[1] || "home"} style={{ "--es-accent": page?.color || "#aac6f2" } as CSSProperties}>
    <a href="#page-content" className="es-skip">Skip to content</a>
    <SiteChrome />
    <Content id="page-content" className={immersive ? "es-immersive-content" : "es-page"} tabIndex={-1}>
      {!immersive && !detail && page && <PageIntro page={page} />}
      <div className={immersive ? undefined : "es-page-content"}>{children}</div>
    </Content>
    {!immersive && <footer className="es-footer"><div><Link href="/" className="es-brand"><Orbit size={25} strokeWidth={1.3} />earthsphere<span>.</span></Link><p>Made on Earth. For the endlessly curious.</p></div><nav aria-label="Footer"><Link href="/about">Our story</Link><a href="https://api.nasa.gov/" target="_blank" rel="noopener noreferrer">NASA Open APIs <ArrowUpRight size={12} /></a><a href="https://eyes.nasa.gov/apps/earth/#/" target="_blank" rel="noopener noreferrer">NASA Eyes on Earth <ArrowUpRight size={12} /></a></nav><span>Independent platform · Open science</span></footer>}
  </div></MotionConfig>;
}
