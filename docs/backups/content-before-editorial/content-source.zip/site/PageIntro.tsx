"use client";

import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";
import Link from "next/link";
import { ArrowUpRight, ChevronRight } from "lucide-react";
import type { Destination } from "./catalog";

export function PageIntro({ page }: { page: Destination }) {
  const ref = useRef<HTMLElement>(null);
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 75]);
  const rotate = useTransform(scrollYProgress, [0, 1], [-18, 20]);
  return <section className="es-intro" ref={ref}>
    <div className="es-intro-copy">
      <nav className="es-breadcrumb" aria-label="Breadcrumb"><Link href="/">EarthSphere</Link><ChevronRight size={12} /><span>{page.group}</span></nav>
      <motion.div initial={reduced ? false : { opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .65, ease: [.16, 1, .3, 1] }}>
        <p className="es-kicker"><span />{page.label}</p>
        <h1>{page.title}<br /><em>{page.emphasis}</em></h1>
        <p className="es-intro-description">{page.description}</p>
      </motion.div>
      <a className="es-source" href={page.sourceUrl} target="_blank" rel="noopener noreferrer">{page.source}<ArrowUpRight size={12} /><span className="sr-only">Opens in a new tab</span></a>
    </div>
    <motion.div className={`es-intro-art es-art-${page.group.toLowerCase()}`} style={reduced ? undefined : { y, rotate }} aria-hidden="true"><div className="es-art-orbit" /><div className="es-art-orbit es-art-orbit-two" /><div className="es-art-world"><page.icon size={78} strokeWidth={.65} /></div><span className="es-art-coordinate">EARTHSPHERE / {page.group.toUpperCase()}<br />A NEW PERSPECTIVE</span><i /><b>+</b></motion.div>
  </section>;
}
