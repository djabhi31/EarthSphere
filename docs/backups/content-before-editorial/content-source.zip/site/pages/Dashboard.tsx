"use client";
import Link from "next/link";
import { useState } from "react";
import { AIBriefingModal } from "@/components/features/AIBriefingModal";
import { ArrowRight, ArrowUpRight, Globe2, Orbit, Sun } from "lucide-react";
import { useAPODSingle, useDONKISolarFlares, useNeoFeed } from "@/hooks/useNasaApi";
import { useEvents } from "@/hooks/useEvents";
import { DESTINATIONS } from "../catalog";
import { DataState } from "../DataState";
import { NasaImage } from "../NasaImage";

function dateOffset(days: number) { const date = new Date(); date.setUTCDate(date.getUTCDate() + days); return date.toISOString().slice(0,10); }
export default function DashboardPage() {
  const [briefing, setBriefing] = useState(false);
  const photo = useAPODSingle();
  const earth = useEvents({ status: "open", limit: 80 });
  const neo = useNeoFeed(dateOffset(0), dateOffset(6));
  const sun = useDONKISolarFlares(dateOffset(-30), dateOffset(0));
  const modules = [
    { title: "A living planet", href: "/events", label: "Open events in this sample", count: earth.data?.events.length, error: earth.isError, loading: earth.isPending, icon: Globe2, detail: "NASA EONET / UP TO 80 OBSERVATIONS" },
    { title: "Our cosmic neighborhood", href: "/asteroids", label: "Objects approaching this week", count: neo.data?.element_count, error: neo.isError, loading: neo.isPending, icon: Orbit, detail: "NASA NEOWS / NEXT 7 DAYS" },
    { title: "The Sun’s activity", href: "/space-weather", label: "Recorded solar flares", count: sun.data?.length, error: sun.isError, loading: sun.isPending, icon: Sun, detail: "NASA DONKI / LAST 30 DAYS" },
  ];
  return <>
    <div className="es-dashboard-top"><article className="es-card es-dashboard-picture"><DataState loading={photo.isPending} error={photo.error} retry={() => { void photo.refetch(); }} />{photo.data && !photo.isError && <><NasaImage key={photo.data.url} src={photo.data.media_type === "image" ? photo.data.url : photo.data.thumbnail_url} alt={photo.data.title} eager /><div className="es-dashboard-picture-copy"><span>PICTURE OF THE DAY / {photo.data.date}</span><h2>{photo.data.title}</h2><Link href="/apod">Discover the story<ArrowUpRight size={17} /></Link></div></>}</article><Link href="/explore" className="es-card es-dashboard-globe"><div className="es-dashboard-earth" /><div><p className="es-kicker">A CHANGE OF PERSPECTIVE</p><h2>Your world.<br /><em>All around you.</em></h2><p>Step into the 3D Earth explorer.</p><span>Explore the planet<ArrowUpRight size={17} /></span></div></Link></div>
    <div className="es-dashboard-stats">{modules.map(module => <Link className="es-card es-dashboard-stat" href={module.href} key={module.href}><div><module.icon size={21} strokeWidth={1.3} /><ArrowUpRight size={15} /></div><h2>{module.title}</h2><strong>{module.loading || module.error || module.count === undefined ? "—" : module.count.toLocaleString()}</strong><p>{module.error ? "Source unavailable · Open for details" : module.loading ? "Connecting to the source…" : module.label}</p><small>{module.detail}</small></Link>)}</div>
    <div className="es-dashboard-briefing"><p>A quick overview of the events in this sample.</p><button className="es-button es-button-secondary" disabled={earth.isPending || earth.isError} onClick={() => setBriefing(true)}>Open event briefing<ArrowUpRight size={14} /></button></div>
    <AIBriefingModal events={earth.data?.events || []} isOpen={briefing} onClose={() => setBriefing(false)} />
    <div className="es-section-heading"><div><h2>Your next discovery starts here.</h2><p>Choose a destination. There’s a whole universe to explore.</p></div><Link href="/about">About EarthSphere<ArrowRight size={14} /></Link></div>
    <div className="es-tool-grid">{DESTINATIONS.filter(item => !["/dashboard", "/about"].includes(item.href)).map(item => <Link href={item.href} key={item.href}><item.icon size={23} strokeWidth={1.25} /><div><small>{item.group.toUpperCase()}</small><h3>{item.label}</h3></div><ArrowUpRight size={15} /></Link>)}</div>
    <div className="es-platform-links"><span>MORE PERSPECTIVES</span><a href="https://godseyeview.earthsphere.in" target="_blank" rel="noopener noreferrer">God’s Eye View<ArrowUpRight size={15} /></a><a href="https://worldmonitor.earthsphere.in" target="_blank" rel="noopener noreferrer">World Monitor<ArrowUpRight size={15} /></a><a href="https://eyes.nasa.gov/apps/earth/#/" target="_blank" rel="noopener noreferrer">NASA Eyes on Earth<ArrowUpRight size={15} /></a></div>
  </>;
}
