import type { Metadata } from 'next';
import { ExploreClient } from '@/components/explore/ExploreClient';

export const metadata: Metadata = {
  title: 'Earth Explorer — NASA Eyes',
  description: 'Explore Earth with NASA’s official Eyes on the Earth viewer, including its spacecraft, observation layers, and time controls.',
};

export default function ExplorePage() {
  return <main className="h-dvh overflow-hidden bg-black"><ExploreClient /></main>;
}
