"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUpRight, Maximize2, Minimize2, RotateCw, X } from "lucide-react";
import styles from "./explore.module.css";

const NASA_EYES_URL = "https://eyes.nasa.gov/apps/earth/#/";

export function ExploreClient() {
  const workspace = useRef<HTMLDivElement>(null);
  const [attempt, setAttempt] = useState(0);
  const [frameLoaded, setFrameLoaded] = useState(false);
  const [slow, setSlow] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (frameLoaded) return;
    const timer = window.setTimeout(() => setSlow(true), 20000);
    return () => window.clearTimeout(timer);
  }, [attempt, frameLoaded]);

  useEffect(() => {
    const syncFullscreen = () => setFullscreen(document.fullscreenElement === workspace.current);
    document.addEventListener("fullscreenchange", syncFullscreen);
    return () => document.removeEventListener("fullscreenchange", syncFullscreen);
  }, []);

  function reload() {
    setFrameLoaded(false);
    setSlow(false);
    setNotice(null);
    setAttempt(value => value + 1);
  }

  async function toggleFullscreen() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else if (workspace.current?.requestFullscreen) await workspace.current.requestFullscreen();
      else setNotice("Fullscreen isn’t available in this browser. You can open the viewer directly at NASA.");
    } catch {
      setNotice("Your browser couldn’t enter fullscreen. You can open the viewer directly at NASA.");
    }
  }

  return (
    <div ref={workspace} className={styles.workspace}>
      <div className={styles.toolbar}>
        <div className={styles.identity}>
          <h1>Earth Explorer</h1>
          <span className={styles.attribution}>NASA Eyes on the Earth</span>
        </div>
        <div className={styles.actions}>
          <button type="button" onClick={reload} aria-label="Reload NASA Earth viewer" title="Reload viewer">
            <RotateCw size={14} />
          </button>
          <button type="button" onClick={toggleFullscreen} aria-label={fullscreen ? "Exit fullscreen" : "Open viewer fullscreen"} title={fullscreen ? "Exit fullscreen" : "Fullscreen"}>
            {fullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}<span>Fullscreen</span>
          </button>
          <a href={NASA_EYES_URL} target="_blank" rel="noopener noreferrer" aria-label="Open NASA Eyes on the Earth in a new tab" title="Open directly at NASA">
            <span>Open at NASA</span><ArrowUpRight size={15} />
          </a>
        </div>
      </div>

      <div className={styles.viewport}>
        {!frameLoaded && <div className={styles.loading} role="status"><span />Connecting to NASA Eyes…</div>}
        <iframe
          key={attempt}
          className={styles.viewer}
          src={NASA_EYES_URL}
          title="NASA Eyes on the Earth — interactive 3D Earth explorer"
          allow="fullscreen; autoplay"
          allowFullScreen
          referrerPolicy="strict-origin-when-cross-origin"
          loading="eager"
          onLoad={() => { setFrameLoaded(true); setSlow(false); }}
          onError={() => { setFrameLoaded(true); setNotice("The NASA viewer couldn’t load. Try again or open it directly at NASA."); }}
        />
        {(notice || slow) && (
          <div className={styles.notice} role="status">
            <p>{notice || "Taking longer than expected? Try reloading or open the viewer directly at NASA."}</p>
            <div><button type="button" onClick={reload}>Reload</button><a href={NASA_EYES_URL} target="_blank" rel="noopener noreferrer">Open at NASA<ArrowUpRight size={13} /></a></div>
            <button type="button" className={styles.dismiss} aria-label="Dismiss viewer message" onClick={() => { setSlow(false); setNotice(null); }}><X size={16} /></button>
          </div>
        )}
      </div>
    </div>
  );
}
