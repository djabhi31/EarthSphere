"use client";

import { usePathname } from "next/navigation";
import { Navbar } from "./Navbar";
import { Navbar as ClassicNavbar } from "./ClassicNavbar";
import { CustomCursor } from "@/components/ui/CustomCursor";
import { ScrollProgress } from "@/components/ui/ScrollProgress";

/** The cinematic homepage supplies its own navigation and motion controls. */
export function SiteChrome() {
  const pathname = usePathname();
  if (pathname === "/landing-v1") return null;
  if (pathname === "/landing-classic") return <><ScrollProgress /><ClassicNavbar /><CustomCursor /></>;
  return <Navbar key={pathname} />;
}
