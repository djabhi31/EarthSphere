import { ExploreClient } from '@/components/explore/ExploreClient';
import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Earth in 3D',
  description: 'Explore a 3D Earth, NASA imagery layers, and illustrative satellite orbits.',
};

export default function ExplorePage() {
  return (
    <main className="relative h-svh bg-black overflow-hidden">
      <ExploreClient />
    </main>
  );
}
