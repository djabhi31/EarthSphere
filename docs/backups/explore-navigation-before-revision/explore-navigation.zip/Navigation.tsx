"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { AnimatePresence, motion, useMotionValueEvent, useReducedMotion, useScroll } from "motion/react";
import { ArrowRight, ArrowUpRight, Bookmark, ChevronDown, Command, Menu, Orbit, Search, X } from "lucide-react";
import { Preferences } from "./Preferences";
import { SoundToggle } from "@/components/ui/SoundToggle";
import { WatchlistPanel } from "@/components/features/WatchlistPanel";
import { DESTINATIONS, type Destination } from "./catalog";
import { Dialog } from "./Dialog";

const GROUPS = ["Earth", "Space", "Discover"] as const;
export function Navigation() {
  const pathname = usePathname();
  const router = useRouter();
  const reduced = useReducedMotion();
  const root = useRef<HTMLElement>(null);
  const searchInput = useRef<HTMLInputElement>(null);
  const [menu, setMenu] = useState<Destination["group"] | null>(null);
  const [mobile, setMobile] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [watchlist, setWatchlist] = useState(false);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(0);
  const [scrolled, setScrolled] = useState(false);
  const { scrollY } = useScroll();
  useMotionValueEvent(scrollY, "change", value => setScrolled(value > 24));
  const matches = useMemo(() => DESTINATIONS.filter(item => `${item.label} ${item.description} ${item.source}`.toLowerCase().includes(query.toLowerCase())).slice(0, 12), [query]);
  const isActive = (href: string) => pathname === href || pathname.startsWith(href + "/");
  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") { event.preventDefault(); setMenu(null); setSearchOpen(value => !value); }
      if (event.key === "Escape") {
        const trigger = root.current?.querySelector<HTMLButtonElement>('button[aria-expanded="true"]');
        if (trigger) { setMenu(null); trigger.focus(); }
      }
    };
    const outside = (event: PointerEvent) => { if (!root.current?.contains(event.target as Node)) setMenu(null); };
    window.addEventListener("keydown", key);
    document.addEventListener("pointerdown", outside);
    return () => { window.removeEventListener("keydown", key); document.removeEventListener("pointerdown", outside); };
  }, []);
  const close = () => { setMenu(null); setMobile(false); setSearchOpen(false); };
  const navigate = (href: string) => { close(); router.push(href); };
  return <>
    <header ref={root} className={`es-nav-wrap ${scrolled ? "es-nav-scrolled" : ""}`} onBlur={event => { if (event.relatedTarget && !event.currentTarget.contains(event.relatedTarget)) setMenu(null); }}>
      <motion.div className="es-nav" initial={reduced ? false : { y: -18, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: .65, ease: [.16, 1, .3, 1] }}>
        <Link href="/" className="es-brand" onClick={close} aria-label="EarthSphere home"><span className="es-brand-orbit"><Orbit size={28} strokeWidth={1.3} /></span>earthsphere<span>.</span></Link>
        <nav className="es-nav-links" aria-label="Main navigation">
          <Link href="/dashboard" className={isActive("/dashboard") ? "es-nav-current" : ""} aria-current={isActive("/dashboard") ? "page" : undefined} onClick={close}>Mission control{isActive("/dashboard") && <motion.i layoutId="site-nav-active" />}</Link>
          {GROUPS.map(group => <button key={group} aria-expanded={menu === group} aria-controls={`navigation-${group}`} className={DESTINATIONS.some(item => item.group === group && isActive(item.href)) ? "es-nav-current" : ""} onClick={() => setMenu(menu === group ? null : group)} onKeyDown={event => { if (event.key === "ArrowDown") { event.preventDefault(); setMenu(group); requestAnimationFrame(() => document.getElementById(`navigation-${group}`)?.querySelector<HTMLAnchorElement>("a")?.focus()); } }}>
            {group}<ChevronDown size={12} style={{ transform: menu === group ? "rotate(180deg)" : undefined }} />{DESTINATIONS.some(item => item.group === group && isActive(item.href)) && !isActive("/dashboard") && <motion.i layoutId="site-nav-active" />}
          </button>)}
        </nav>
        <div className="es-nav-actions">
          <button className="es-nav-search" aria-label="Search pages (Control or Command K)" onClick={() => { setMenu(null); setSearchOpen(true); }}><Search size={16} /><kbd>⌘ K</kbd></button>
          <button className="es-nav-bookmark" aria-label="Open saved events" onClick={() => setWatchlist(true)}><Bookmark size={16} /></button>
          <Link className="es-nav-launch" href="/explore" onClick={close}>Explore Earth<ArrowUpRight size={15} /></Link>
          <button className="es-nav-mobile" aria-label="Open navigation" onClick={() => setMobile(true)}><Menu size={22} /></button>
        </div>
        <AnimatePresence>
          {menu && <motion.div id={`navigation-${menu}`} className="es-mega" initial={{ opacity: 0, y: reduced ? 0 : 12, rotateX: reduced ? 0 : -6 }} animate={{ opacity: 1, y: 0, rotateX: 0 }} exit={{ opacity: 0, y: reduced ? 0 : 6 }} transition={{ duration: .22 }}>
            <div className="es-mega-heading"><span>EXPLORE / {menu.toUpperCase()}</span><button onClick={() => setMenu(null)} aria-label="Close navigation menu"><X size={16} /></button></div>
            <div className="es-mega-grid">{DESTINATIONS.filter(item => item.group === menu).map((item, index) => <Link href={item.href} key={item.href} onClick={close} aria-current={isActive(item.href) ? "page" : undefined} style={{ "--item-delay": `${index * 25}ms` } as React.CSSProperties}><span className="es-menu-icon"><item.icon size={19} strokeWidth={1.35} /></span><span><strong>{item.label}</strong><small>{item.source.replace("NASA · ", "")}</small></span><ArrowUpRight size={14} /></Link>)}</div>
            <div className="es-mega-footer"><span>Follow your curiosity.</span><Link href="/" onClick={close}>Take the 3D journey <ArrowRight size={14} /></Link></div>
          </motion.div>}
        </AnimatePresence>
      </motion.div>
    </header>
    <Dialog open={searchOpen} onClose={() => setSearchOpen(false)} title="Find your next discovery">
      <div className="es-search-heading"><Command size={18} /><span>FIND YOUR NEXT DISCOVERY</span></div>
      <label className="es-search-input"><Search size={21} /><input ref={searchInput} autoFocus placeholder="Planets, images, natural events…" value={query} onChange={event => { setQuery(event.target.value); setSelected(0); }} aria-label="Search EarthSphere pages" aria-controls="site-search-results" onKeyDown={event => { if (event.key === "ArrowDown") { event.preventDefault(); setSelected(value => Math.min(value + 1, matches.length - 1)); } if (event.key === "ArrowUp") { event.preventDefault(); setSelected(value => Math.max(0, value - 1)); } if (event.key === "Enter" && matches[selected]) { event.preventDefault(); navigate(matches[selected].href); } }} /></label>
      <div id="site-search-results" className="es-search-results">{matches.length ? matches.map((item, index) => <Link key={item.href} href={item.href} data-selected={index === selected} onClick={close} onFocus={() => setSelected(index)}><item.icon size={19} /><span><strong>{item.label}</strong><small>{item.group} / {item.source}</small></span><ArrowUpRight size={16} /></Link>) : <p className="es-search-empty">No pages found. Try “Earth”, “Mars”, or “images”.</p>}</div>
      <div className="es-search-footer"><span>↑ ↓ to browse · Enter to open · Esc to close</span><Preferences /><SoundToggle /></div>
    </Dialog>
    <Dialog open={mobile} onClose={() => setMobile(false)} title="EarthSphere navigation">
      <Link href="/" className="es-brand" onClick={close}><Orbit size={26} />earthsphere<span>.</span></Link>
      <div className="es-mobile-groups">{GROUPS.map(group => <section key={group}><h2>{group}</h2>{DESTINATIONS.filter(item => item.group === group).map(item => <Link href={item.href} key={item.href} onClick={close} aria-current={isActive(item.href) ? "page" : undefined}><item.icon size={17} />{item.label}<ArrowUpRight size={14} /></Link>)}</section>)}</div>
      <div className="es-mobile-bottom"><button onClick={() => { setMobile(false); setWatchlist(true); }}><Bookmark size={16} />Saved events</button><Preferences /><SoundToggle /></div>
    </Dialog>
    <WatchlistPanel isOpen={watchlist} onClose={() => setWatchlist(false)} />
  </>;
}
