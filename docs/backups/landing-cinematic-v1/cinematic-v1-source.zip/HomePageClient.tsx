"use client";

export { default } from "@/components/landing/cinematic/CinematicLanding";
