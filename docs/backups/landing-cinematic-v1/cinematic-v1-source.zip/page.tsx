import type { Metadata } from 'next';
import HomePageClient from './HomePageClient';

export const metadata: Metadata = {
  title: { absolute: 'EarthSphere — One planet. Infinite perspective.' },
  description: 'A living planet. An ever-expanding universe. Explore Earth observation, satellite orbits, and deep-space discovery with NASA open data.',
  keywords: ['NASA', 'EONET', 'Earth', 'Events', 'Wildfires', 'Storms', 'Volcanoes', 'Live Tracking'],
  openGraph: {
    title: 'EarthSphere — One planet. Infinite perspective.',
    description: 'Get a little closer to everything. Earth observation, orbital tracking, and deep-space discovery, powered by NASA open data.',
    url: 'https://earthsphere.in',
    siteName: 'EarthSphere',
    images: [
      {
        url: '/og-image.jpg', // Placeholder for OG image
        width: 1200,
        height: 630,
      },
    ],
    locale: 'en_US',
    type: 'website',
  },
};

export default function Page() {
  return <HomePageClient />;
}
