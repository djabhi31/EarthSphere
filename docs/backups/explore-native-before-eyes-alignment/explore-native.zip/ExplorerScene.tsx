"use client";

import { Component, Suspense, useEffect, useImperativeHandle, useMemo, useRef, useState, type ReactNode, type Ref } from "react";
import { Canvas, useFrame, useLoader, useThree, type ThreeEvent } from "@react-three/fiber";
import { Html, Line, OrbitControls } from "@react-three/drei";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import * as THREE from "three";
import { EARTH_KM, cameraFlightStep, geographicVector, orbitPath, propagatedPosition, solarPoint, vectorGeographic, type GeoPoint } from "@/lib/explore/astronomy";
import { type Mission, NORAD_IDS } from "@/lib/explore/missions";
import type { TLESatellite } from "@/lib/types/nasa";
import type { Observation } from "./useExplorerData";
import { SpacecraftModel } from "./SpacecraftModel";
import styles from "./explore.module.css";

export type SceneCommands = { flyTo: (point: GeoPoint, distance?: number) => void; rotate: (latitude: number, longitude: number) => void; zoom: (factor: number) => void; reset: () => void; snapshot: () => void };
export type GlobeEvent = { id: string; title: string; point: GeoPoint; color: string; date: string };
type Props = {
  apiRef: Ref<SceneCommands>; time: number; playing: boolean; reduced: boolean;
  missions: Mission[]; records: Record<number, TLESatellite>; selectedMission: Mission | null; follow: boolean;
  observation?: Observation; opacity: number; showSatellites: boolean; showOrbits: boolean; showGroundTrack: boolean;
  showCities: boolean; showGrid: boolean; dayNight: boolean; autoRotate: boolean;
  events: GlobeEvent[]; selectedEvent: string | null;
  inspector: boolean; comparison: "none" | "person" | "bus";
  onMission: (mission: Mission) => void; onEvent: (id: string) => void; onPoint: (point: GeoPoint) => void;
  onReady: () => void; onError: (message: string) => void;
  onInteract: () => void;
};

class SceneBoundary extends Component<{ children: ReactNode; onError: (message: string) => void }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch() { this.props.onError("The 3D renderer could not start. Enable WebGL in your browser, then reload the scene."); }
  render() { return this.state.failed ? <div className={styles.sceneFallback}><span>3D view unavailable</span><p>The data panels and archive remain available.</p></div> : this.props.children; }
}
const CITIES: [string, number, number][] = [["New York", 40.7, -74], ["London", 51.5, -.12], ["New Delhi", 28.6, 77.2], ["Tokyo", 35.7, 139.7], ["Sydney", -33.9, 151.2], ["Cape Town", -33.9, 18.4], ["São Paulo", -23.5, -46.6], ["Singapore", 1.3, 103.8], ["Los Angeles", 34, -118.2], ["Cairo", 30, 31.2]];
function starPositions() {
  let seed = 12345;
  const random = () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646;
  const points = new Float32Array(1400 * 3);
  for (let i = 0; i < points.length; i += 3) { const y = random() * 2 - 1, angle = random() * Math.PI * 2, radius = 25 + random() * 35; points.set([Math.sqrt(1 - y * y) * Math.cos(angle) * radius, y * radius, Math.sqrt(1 - y * y) * Math.sin(angle) * radius], i); }
  return points;
}

function Earth({ observation, opacity, showGrid, showCities, dayNight, time, onPoint }: Pick<Props, "observation" | "opacity" | "showGrid" | "showCities" | "dayNight" | "time" | "onPoint">) {
  const [source, relief, water, clouds] = useLoader(THREE.TextureLoader, ["/textures/earth-blue-marble.jpg", "/textures/earth-topology.png", "/textures/earth-water.png", "/textures/earth-clouds.png"]);
  const map = useMemo(() => { const texture = source.clone(); texture.colorSpace = THREE.SRGBColorSpace; texture.anisotropy = 8; texture.needsUpdate = true; return texture; }, [source]);
  useEffect(() => () => map.dispose(), [map]);
  const overlay = useMemo(() => { if (!observation) return null; const texture = new THREE.CanvasTexture(observation.canvas); texture.colorSpace = THREE.SRGBColorSpace; texture.anisotropy = 4; return texture; }, [observation]);
  useEffect(() => () => overlay?.dispose(), [overlay]);
  const sun = solarPoint(time);
  const position = geographicVector(sun.latitude, sun.longitude, 10);
  const onClick = (event: ThreeEvent<MouseEvent>) => { if (event.delta > 5) return; event.stopPropagation(); onPoint(vectorGeographic(event.point.x, event.point.y, event.point.z)); };
  const grid = useMemo(() => {
    const lines: [number, number, number][][] = [];
    for (let latitude = -60; latitude <= 60; latitude += 30) lines.push(Array.from({ length: 181 }, (_, i) => geographicVector(latitude, -180 + i * 2, 1.007)));
    for (let longitude = -180; longitude < 180; longitude += 30) lines.push(Array.from({ length: 91 }, (_, i) => geographicVector(-90 + i * 2, longitude, 1.007)));
    return lines;
  }, []);
  return <>
    <ambientLight intensity={dayNight ? .24 : 1.8} />
    <directionalLight position={position} intensity={dayNight ? 2.5 : .6} color="#e7f0ff" />
    <mesh onClick={onClick}>
      <sphereGeometry args={[1, 128, 96]} />
      <meshPhongMaterial map={map} bumpMap={relief} bumpScale={.006} specularMap={water} specular="#385567" shininess={22} />
    </mesh>
    {overlay && <mesh onClick={onClick}><sphereGeometry args={[1.003, 128, 96]} /><meshBasicMaterial map={overlay} transparent opacity={opacity} depthWrite={false} /></mesh>}
    {!overlay && <mesh><sphereGeometry args={[1.008, 96, 64]} /><meshPhongMaterial color="#edf5ff" alphaMap={clouds} transparent opacity={.19} depthWrite={false} /></mesh>}
    <mesh scale={1.022}>
      <sphereGeometry args={[1, 96, 64]} />
      <shaderMaterial transparent depthWrite={false} side={THREE.BackSide} blending={THREE.AdditiveBlending}
        vertexShader="varying vec3 vN; varying vec3 vP; void main(){vN=normalize(normalMatrix*normal);vec4 p=modelViewMatrix*vec4(position,1.0);vP=p.xyz;gl_Position=projectionMatrix*p;}"
        fragmentShader="varying vec3 vN; varying vec3 vP; void main(){float rim=pow(1.0-abs(dot(normalize(vN),normalize(-vP))),3.8);gl_FragColor=vec4(.17,.43,.9,rim*.8);}" />
    </mesh>
    {showGrid && grid.map((line, i) => <Line key={i} points={line} lineWidth={.5} color="#b4d4e6" transparent opacity={.2} />)}
    {showCities && CITIES.map(([name, lat, lon]) => <Html key={name} position={geographicVector(lat, lon, 1.012)} center occlude zIndexRange={[3, 0]}><span className={styles.city}>{name}</span></Html>)}
  </>;
}

function SatelliteMarker({ mission, tle, time, selected, onClick }: { mission: Mission; tle: TLESatellite; time: number; selected: boolean; onClick: () => void }) {
  const group = useRef<THREE.Group>(null);
  const { invalidate } = useThree();
  const position = propagatedPosition(tle, time);
  useFrame((_, delta) => {
    if (!position || !group.current) return;
    const target = geographicVector(position.latitude, position.longitude, 1 + position.altitude / EARTH_KM);
    if (group.current.position.length() < .5) group.current.position.set(...target);
    else group.current.position.set(...cameraFlightStep(group.current.position.toArray(), target, 1 - Math.exp(-delta * 14)));
    if (Math.hypot(...target.map((value, i) => value - group.current!.position.getComponent(i))) > .00001) invalidate();
  });
  if (!position) return null;
  return <group ref={group}>
    <mesh onClick={event => { event.stopPropagation(); onClick(); }}>
      <sphereGeometry args={[selected ? .014 : .009, 12, 12]} /><meshBasicMaterial color={selected ? "#f3cd88" : "#9cbff4"} />
    </mesh>
    <Html center position={[0, .03, 0]} occlude zIndexRange={[4, 0]}><button className={`${styles.satelliteTag} ${selected ? styles.tagSelected : ""}`} onClick={onClick}>{mission.title}</button></Html>
  </group>;
}

function Controls(props: Props) {
  const { onError, inspector, time } = props;
  const { camera, gl, scene, invalidate, size } = useThree();
  const controls = useRef<OrbitControlsImpl>(null);
  const destination = useRef<THREE.Vector3 | null>(null);
  const [initial] = useState(() => new THREE.Vector3(...geographicVector(18, solarPoint(time).longitude + 35, 3.4)));
  const previousFollow = useRef(false);
  useEffect(() => { camera.position.copy(inspector ? new THREE.Vector3(5, 4, 8) : initial); camera.lookAt(0, 0, 0); controls.current?.target.set(0, 0, 0); controls.current?.update(); destination.current = null; invalidate(); }, [camera, inspector, initial, invalidate]);
  useEffect(() => {
    const loss = (event: Event) => { event.preventDefault(); onError("The browser lost its graphics context. Reload the scene to reconnect."); };
    gl.domElement.addEventListener("webglcontextlost", loss);
    return () => gl.domElement.removeEventListener("webglcontextlost", loss);
  }, [gl, onError]);
  useImperativeHandle(props.apiRef, () => ({
    flyTo: (point, distance = 2.55) => { destination.current = new THREE.Vector3(...geographicVector(point.latitude, point.longitude, distance)); invalidate(); },
    rotate: (latitude, longitude) => { const current = vectorGeographic(camera.position.x, camera.position.y, camera.position.z); destination.current = new THREE.Vector3(...geographicVector(Math.max(-85, Math.min(85, current.latitude + latitude)), current.longitude + longitude, camera.position.length())); invalidate(); },
    zoom: factor => { destination.current = camera.position.clone().normalize().multiplyScalar(THREE.MathUtils.clamp(camera.position.length() * factor, inspector ? 5 : 1.2, inspector ? 24 : 16)); invalidate(); },
    reset: () => { controls.current?.target.set(0, 0, 0); destination.current = inspector ? new THREE.Vector3(5, 4, 8) : initial.clone(); invalidate(); },
    snapshot: () => {
      try { gl.render(scene, camera); const canvas = document.createElement("canvas"); canvas.width = gl.domElement.width; canvas.height = gl.domElement.height + 48; const context = canvas.getContext("2d"); if (!context) return; context.fillStyle = "#03070d"; context.fillRect(0, 0, canvas.width, canvas.height); context.drawImage(gl.domElement, 0, 0); context.fillStyle = "#b8cbe0"; context.font = "12px sans-serif"; context.fillText(`EarthSphere · NASA / JPL data · ${new Date(time).toISOString()}`, 18, canvas.height - 19); const link = document.createElement("a"); link.download = `earthsphere-${new Date(time).toISOString().slice(0, 10)}.png`; link.href = canvas.toDataURL("image/png"); link.click(); } catch { onError("The browser could not export this view."); }
    },
  }), [camera, gl, scene, initial, invalidate, inspector, time, onError]);
  useFrame((_, delta) => {
    if (destination.current) {
      camera.position.set(...cameraFlightStep(camera.position.toArray(), destination.current.toArray(), props.reduced ? 1 : 1 - Math.exp(-delta * 5)));
      controls.current?.update();
      if (camera.position.distanceTo(destination.current) < .003) destination.current = null;
      else invalidate();
    }
    if (!inspector && props.follow && props.selectedMission) {
      const tle = props.records[NORAD_IDS[props.selectedMission.target_entity]];
      const point = tle && propagatedPosition(tle, time);
      if (point) { const target = geographicVector(point.latitude, point.longitude, Math.max(2.5 + point.altitude / EARTH_KM, camera.position.length())); camera.position.set(...cameraFlightStep(camera.position.toArray(), target, props.reduced ? 1 : 1 - Math.exp(-delta * (previousFollow.current ? 8 : 3)))); controls.current?.update(); }
    }
    previousFollow.current = props.follow;
  });
  const perspective = camera as THREE.PerspectiveCamera;
  useEffect(() => { const fov = inspector ? 44 : size.width < 600 ? 49 : 42; perspective.setFocalLength(perspective.getFilmHeight() / (2 * Math.tan(fov * Math.PI / 360))); invalidate(); }, [perspective, size.width, inspector, invalidate]);
  return <OrbitControls ref={controls} enablePan={false} enableDamping dampingFactor={.08} rotateSpeed={.55} zoomSpeed={.7} minDistance={inspector ? 5 : 1.2} maxDistance={inspector ? 24 : 8} autoRotate={props.autoRotate && !props.follow && !props.reduced} autoRotateSpeed={.3} onStart={() => { destination.current = null; props.onInteract(); }} />;
}

function Contents(props: Props) {
  const { time, inspector, onReady } = props;
  const stars = useMemo(() => starPositions(), []);
  const uniqueMissions = props.missions.filter((mission, index, all) => NORAD_IDS[mission.target_entity] === 25544 ? mission.target_entity === "sc_iss" : NORAD_IDS[mission.target_entity] && all.findIndex(other => NORAD_IDS[other.target_entity] === NORAD_IDS[mission.target_entity]) === index);
  const minute = Math.floor(time / 60000) * 60000;
  const selectedId = props.selectedMission ? NORAD_IDS[props.selectedMission.target_entity] : undefined;
  const tracks = useMemo(() => Object.entries(props.records).filter(([id]) => props.showOrbits || Number(id) === selectedId).map(([id, tle]) => ({ id: Number(id), orbit: orbitPath(tle, minute), ground: Number(id) === selectedId && props.showGroundTrack ? orbitPath(tle, minute, true) : [] })), [props.records, props.showOrbits, selectedId, minute, props.showGroundTrack]);
  useEffect(() => onReady(), [onReady]);
  return <>
    <color attach="background" args={["#03070d"]} />
    <points><bufferGeometry><bufferAttribute attach="attributes-position" args={[stars, 3]} /></bufferGeometry><pointsMaterial color="#a5bfdf" size={.035} sizeAttenuation transparent opacity={.65} /></points>
    {inspector && props.selectedMission ? <>
      <ambientLight intensity={1.5} /><directionalLight position={[4, 7, 5]} intensity={3} color="#c8e2ff" /><directionalLight position={[-6, -3, 2]} intensity={2} color="#c99859" />
      <SpacecraftModel mission={props.selectedMission} comparison={props.comparison} />
      <gridHelper args={[16, 16, "#183042", "#101e2b"]} position={[0, -2.2, 0]} />
    </> : <>
      <Earth {...props} />
      {props.showSatellites && uniqueMissions.map(mission => { const tle = props.records[NORAD_IDS[mission.target_entity]]; return tle && <SatelliteMarker key={mission.target_entity} mission={mission} tle={tle} time={time} selected={NORAD_IDS[mission.target_entity] === selectedId} onClick={() => props.onMission(mission)} />; })}
      {props.showSatellites && tracks.map(track => <group key={track.id}>
        {track.orbit.length > 1 && <Line points={track.orbit} lineWidth={track.id === selectedId ? 1.3 : .65} color={track.id === selectedId ? "#e8c681" : "#5a89c1"} transparent opacity={track.id === selectedId ? .72 : .22} />}
        {track.ground.length > 1 && <Line points={track.ground} lineWidth={1} color="#e8c681" transparent opacity={.7} dashed dashSize={.016} gapSize={.008} />}
      </group>)}
      {props.events.map(event => <mesh key={event.id} position={geographicVector(event.point.latitude, event.point.longitude, 1.012)} onClick={pointer => { pointer.stopPropagation(); props.onEvent(event.id); }}><sphereGeometry args={[props.selectedEvent === event.id ? .016 : .009, 12, 12]} /><meshBasicMaterial color={event.color} /></mesh>)}
    </>}
    <Controls {...props} />
  </>;
}

export default function ExplorerScene(props: Props) {
  return <SceneBoundary onError={props.onError}><Canvas camera={{ position: geographicVector(22, 40, 3.65), fov: 42, near: .005, far: 120 }} dpr={[1, 1.7]} gl={{ antialias: true, alpha: false, preserveDrawingBuffer: true }} frameloop={props.playing || props.autoRotate || props.follow ? "always" : "demand"} aria-label="Interactive 3D Earth. Use the adjacent controls to rotate, zoom, and select observations."><Suspense fallback={null}><Contents {...props} /></Suspense></Canvas></SceneBoundary>;
}
